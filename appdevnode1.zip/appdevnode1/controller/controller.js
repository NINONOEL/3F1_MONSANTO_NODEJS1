const main = {
    index:(req, res) =>{
        res.render('index');
    },
    about:(req, res) =>{
        res.render('about');
    },
    blog:(req, res) =>{
        res.render('blog');
    },
    contact:(req, res) =>{
        res.render('contact');
    },
    pages:(req, res) =>{
        res.render('pages');
    },
    
};
module.exports = main;